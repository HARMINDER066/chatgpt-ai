$(document).ready(function () {
  $(".test").on("click", function () {
    
  });
 
});

