var CLIENT_ID = "873544992293-qtapph4vpk0d2ui2bvblijdmgc9g64ej.apps.googleusercontent.com";
 var custom_data = {
	"baseUrl" : 'https://extenionbackend.techrit.tech/',
	"sendBulkMessageEnable" : true, // true/false = true for enable , false for disable
	"addFriend" : true,
	"addFriendFromComments": true
};
var sendMessageEnable = true;

var groupleadsExtensionId = "cpiekpbnfmakgignhplighcolknncoid"; /// Do not change
